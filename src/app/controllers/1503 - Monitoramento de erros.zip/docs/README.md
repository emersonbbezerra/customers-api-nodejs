# Docs

Esta é um diretório onde encontram-se todos os arquivos de documentação do projeto.

- `Diagrams.mdj` - Arquivo de modelagem de ER - Programa [StarUML](http://staruml.io/).
