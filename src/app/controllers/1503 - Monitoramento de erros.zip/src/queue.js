import "dotenv/config";

import Queue from "./lib/Queue";

Queue.processQueue();
