import app from "./app";

app.listen(process.env.PORT);
